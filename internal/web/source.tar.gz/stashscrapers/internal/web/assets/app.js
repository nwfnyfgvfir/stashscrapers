'use strict';
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const stateNames={available:'依赖齐全',missing_dependency:'缺少依赖',needs_configuration:'需要配置',unsupported:'不支持'};
const operationNames={name:'名称搜索',url:'URL 详情',fragment:'Fragment 详情',query_fragment:'候选详情'};
const phaseNames={idle:'更新计划已就绪',checking:'正在检查上游',downloading:'正在下载完整快照',validating:'正在运行兼容验证',dependencies:'正在验证隔离依赖',switching:'正在切换版本',copying:'正在复制本地资源',failed:'更新失败，当前版本保留',blocked:'已跳过验证失败的提交'};
const errorNames={not_found:'未找到结果',input_error:'输入有误',unsupported:'不支持该操作',missing_dependency:'缺少运行依赖',needs_configuration:'需要补充配置',target_denied:'目标网站拒绝访问',timeout:'请求超时',parse_error:'解析失败',network_error:'网络请求失败',script_error:'脚本执行失败',busy:'版本操作正在进行',disabled:'刮削器已停用',unauthorized:'需要服务访问凭据',version_conflict:'规则版本已变化',browser_error:'浏览器执行失败'};
let scrapers=[],configuration=null,updates=null,selected='',busy=false,abortController=null,toastTimer,settingsDirty=false;
function node(tag,cls,text){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;}
function short(v){return v?v.slice(0,12):'尚未安装';}
function date(v){return !v||v.startsWith('0001')?'尚无记录':new Date(v).toLocaleString('zh-CN',{timeZone:configuration?.update.timezone||'Asia/Shanghai',hour12:false});}
function toast(text){$('#toast').textContent=text;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),6500);}
async function api(path,options={}){
  const headers={'Content-Type':'application/json',...options.headers};const token=sessionStorage.getItem('stash-token');if(token)headers.Authorization=`Bearer ${token}`;
  const response=await fetch(path,{...options,headers});const body=await response.json();
  if(!response.ok){const e=new Error(`${errorNames[body.error?.code]||'操作失败'}：${body.error?.message||response.status}`);e.code=body.error?.code;e.response=body;throw e;}return body;
}
function tab(name){$$('.page').forEach(el=>el.classList.toggle('active',el.id===`page-${name}`));$$('.nav').forEach(el=>el.classList.toggle('active',el.dataset.tab===name));$('#page-name').textContent=$(`.nav[data-tab="${name}"]`).textContent.replace(/[▦⌘↻⚙≡\d]/g,'').trim();if(name==='logs')refreshLogs();}
$$('.nav').forEach(el=>el.addEventListener('click',()=>tab(el.dataset.tab)));
async function refresh(){
  try{
    const [library,config,version,health]=await Promise.all([api('/api/scrapers'),api('/api/config'),api('/api/updates'),api('/api/health')]);
    scrapers=library.scrapers;configuration=config;updates=version;$('#service-status').textContent=health.ready?'服务运行中':'资源初始化中';$('#footer-engine').textContent=health.engine;$('#nav-count').textContent=scrapers.length;
    $('#metric-total').textContent=scrapers.length;$('#metric-ready').textContent=scrapers.filter(e=>e.state==='available').length;$('#metric-verified').textContent=scrapers.filter(e=>e.verification==='offline_fixture').length;$('#metric-version').textContent=short(version.state.active);$('#metric-version').title=version.state.active;$('#metric-updated').textContent=`最近成功：${date(version.state.last_success)}`;
    $('#schedule-label').textContent=config.update.enabled?`自动跟随 · ${config.update.daily_at?'每日 '+config.update.daily_at:config.update.interval_hours+' 小时'} · ${config.update.timezone}`:'自动更新已暂停';
    renderLibrary();renderDebugOptions();renderUpdates();if(!settingsDirty)renderSettings();if(selected)renderInspector();
  }catch(e){$('#service-status').textContent='连接需要处理';if(e.code==='unauthorized'){tab('settings');toast('服务已启用认证，请填写 Bearer Token 后连接。');}else toast(e.message);}
}
function renderLibrary(){
  const query=$('#filter').value.toLowerCase(),status=$('#status-filter').value;
  const filtered=scrapers.filter(e=>(!query||`${e.name} ${e.id}`.toLowerCase().includes(query))&&(!status||e.state===status));$('#list-count').textContent=`显示 ${filtered.length} / ${scrapers.length} 个规则`;
  const list=$('#scraper-list');list.replaceChildren();
  if(!filtered.length){const empty=node('div','empty-state');empty.append(node('h3','',scrapers.length?'没有匹配的规则':'尚未安装社区资源'),node('p','',scrapers.length?'试试其他名称或状态筛选。':'服务会自动初始化；进度见「版本与更新」。'));list.append(empty);return;}
  const fragment=document.createDocumentFragment();
  filtered.forEach(e=>{const card=node('button',`scraper-card${e.id===selected?' selected':''}`);card.type='button';card.setAttribute('aria-pressed',e.id===selected);const top=node('div','card-top'),name=node('div');name.append(node('div','card-name',e.name),node('div','card-id',e.id));top.append(node('div','site-icon',e.name.slice(0,1).toUpperCase()),name);const bottom=node('div','card-bottom');bottom.append(node('span',`badge ${e.state}`,stateNames[e.state]||e.state));const objects=[...new Set(e.operations.map(o=>o.object))];objects.forEach(o=>bottom.append(node('span','badge neutral',o==='scene'?'场景':'演员')));if(!e.enabled)bottom.append(node('span','card-disabled','已停用'));card.append(top,bottom);card.addEventListener('click',()=>{selected=e.id;renderLibrary();renderInspector();});fragment.append(card);});list.append(fragment);
}
function renderInspector(){
  const e=scrapers.find(s=>s.id===selected);if(!e)return;const box=$('#inspector');box.replaceChildren();box.append(node('div','eyebrow','SCRAPER DETAILS'),node('h2','',e.name),node('p','id',e.id),node('span',`badge ${e.state}`,stateNames[e.state]),node('p','help',e.reason||'运行时已加载'));
  box.append(node('h3','','对象与操作'));e.operations.forEach(op=>{const row=node('div','capability'),head=node('div');head.append(node('span','',`${op.object==='scene'?'场景':'演员'} · ${operationNames[op.operation]||op.operation}`),node('span',`badge ${op.state}`,stateNames[op.state]));row.append(head,node('small','',`${op.action} · ${op.dependencies.join(' / ')}`));if(op.reason)row.append(node('p','reason',op.reason));box.append(row);});
  box.append(node('h3','','版本与验证'),node('p','id',e.version),node('p','help',e.verification==='offline_fixture'?'已通过本版本的离线 fixture 回归。未据此宣称目标网站在线可用。':'运行能力由配置与依赖检测得到；尚未进行本站离线或在线验证。'));
  const buttons=node('div','button-row'),debug=node('button','primary','进入刮削调试 →'),toggle=node('button','secondary',e.enabled?'停用':'启用');debug.addEventListener('click',()=>{$('#debug-scraper').value=e.id;updateDebugCapability();tab('debug');});toggle.addEventListener('click',()=>mutate(()=>api(`/api/scrapers/${encodeURIComponent(e.id)}`,{method:'PATCH',body:JSON.stringify({enabled:!e.enabled})}),'启用状态已保存'));buttons.append(debug,toggle);box.append(buttons);
  const details=node('details');details.append(node('summary','','独立 Cookie、API Key 与脚本授权'));const form=node('form');const fields={};[['cookie','Cookie'],['api_key','目标站点 API Key'],['api_key_header','API Key 请求头名称']].forEach(([key,label])=>{const l=node('label','',label),input=node('input');input.type=key==='api_key_header'?'text':'password';input.autocomplete='off';input.placeholder=configuration.scrapers[e.id]?.[key]?'已保存；留空保持':'尚未设置';l.append(input);form.append(l);fields[key]=input;});const consent=node('label','check-label'),checkbox=node('input');checkbox.type='checkbox';checkbox.checked=!!configuration.scrapers[e.id]?.script_approved;consent.append(checkbox,document.createTextNode('允许执行本规则中已审核的可信脚本'));form.append(consent);const save=node('button','secondary','保存刮削器设置');save.type='submit';form.append(save);form.addEventListener('submit',event=>{event.preventDefault();const payload={script_approved:checkbox.checked};Object.entries(fields).forEach(([k,input])=>{if(input.value)payload[k]=input.value;});mutate(()=>api(`/api/scrapers/${encodeURIComponent(e.id)}`,{method:'PATCH',body:JSON.stringify(payload)}),'独立设置已保存；新增 Python 依赖需要新快照安装');});details.append(form);box.append(details);
}
function renderDebugOptions(){const select=$('#debug-scraper'),old=select.value;select.replaceChildren();scrapers.filter(e=>e.operations.length).forEach(e=>{const o=node('option','',`${e.name} · ${stateNames[e.state]}`);o.value=e.id;select.append(o);});if(scrapers.some(e=>e.id===old))select.value=old;else if(selected)select.value=selected;updateDebugCapability();}
const debugModes=[['query','name','按名称搜索'],['url','url','按来源 URL'],['fragment','fragment','按 Fragment'],['query_fragment','query_fragment','按搜索候选 Fragment']];
let debugSelectionKey='';
function debugSelection(){
  const entry=scrapers.find(e=>e.id===$('#debug-scraper').value);
  const operation=debugModes.find(([value])=>value===$('#debug-mode').value)?.[1];
  const capabilities=(entry?.operations||[]).filter(op=>op.object===$('#debug-object').value&&op.operation===operation);
  return {entry,capabilities,ready:!!entry?.enabled&&capabilities.some(op=>op.state==='available')};
}
function updateDebugCapability(){
  const entry=scrapers.find(e=>e.id===$('#debug-scraper').value),object=$('#debug-object'),modeSelect=$('#debug-mode');
  [...object.options].forEach(option=>option.disabled=!(entry?.operations||[]).some(op=>op.object===option.value));
  if(![...object.options].some(option=>option.value===object.value&&!option.disabled))object.value=[...object.options].find(option=>!option.disabled)?.value||'';
  const ops=(entry?.operations||[]).filter(op=>op.object===object.value),previousMode=modeSelect.value;
  modeSelect.replaceChildren();
  debugModes.forEach(([value,operation,label])=>{
    const capabilities=ops.filter(op=>op.operation===operation);if(!capabilities.length)return;
    const available=capabilities.some(op=>op.state==='available'),option=node('option','',available?label:`${label} · ${stateNames[capabilities[0].state]}`);
    option.value=value;option.disabled=!available;modeSelect.append(option);
  });
  const choices=[...modeSelect.options];
  modeSelect.value=choices.find(option=>option.value===previousMode&&!option.disabled)?.value||choices.find(option=>!option.disabled)?.value||choices[0]?.value||'';
  modeSelect.disabled=!choices.some(option=>!option.disabled);
  const mode=modeSelect.value,selection=debugSelection();
  const messages=ops.map(op=>`${operationNames[op.operation]}：${stateNames[op.state]}`);
  if(!ops.some(op=>op.operation==='name')&&ops.some(op=>op.operation==='url'))messages.push('本规则不支持按名称或番号搜索，请填写本站详情页 URL。');
  if(entry&&!entry.enabled)messages.push('本刮削器已停用，请先在管理页启用。');
  if(!selection.ready&&selection.capabilities.length)messages.push(selection.capabilities[0].reason||'请先补全此操作的运行依赖或配置。');
  $('#debug-capability').textContent=messages.join('　/　')||'本规则没有可执行的操作。';
  $('#run').disabled=!!abortController||!selection.ready;
  $('#input-label').textContent=mode==='query'?'搜索词':mode==='url'?'来源 URL':'Fragment JSON';
  $('#debug-input').placeholder=mode==='query'?'输入名称或代码（需要规则原生支持名称搜索）':mode==='url'?'https://目标站点/详情地址':'{"url":"https://…"}';
  const key=`${entry?.id}|${object.value}|${mode}`;
  if(key!==debugSelectionKey)$('#debug-input').value='';debugSelectionKey=key;
}
['debug-scraper','debug-object','debug-mode'].forEach(id=>$(`#${id}`).addEventListener('change',updateDebugCapability));
async function execute(payload,search){
  abortController=new AbortController();$('#run').disabled=true;$('#cancel').disabled=false;$('#result-count').textContent='请求运行中';$('#results').replaceChildren(node('p','help','正在发起真实请求，请稍候…'));
  try{const response=await api(search?'/api/search':'/api/detail',{method:'POST',body:JSON.stringify(payload),signal:abortController.signal});$('#raw-result').textContent=JSON.stringify(response,null,2);$('#result-count').textContent=`${response.results.length} ${search?'个候选':'条结果'}`;renderResults(response,payload,search);}
  catch(e){$('#result-count').textContent=e.name==='AbortError'?'已取消':'执行失败';const error=node('div','result-error');error.append(node('span','error-code',e.name==='AbortError'?'cancelled':e.code||'request_error'),document.createTextNode(e.name==='AbortError'?'请求已取消。':e.message));$('#results').replaceChildren(error);$('#raw-result').textContent=JSON.stringify(e.response||{error:e.message},null,2);}
  finally{$('#cancel').disabled=true;abortController=null;updateDebugCapability();}
}
function renderResults(response,payload,search){
  const container=$('#results');container.replaceChildren();response.results.forEach((r,index)=>{const item=node('article','result');item.append(node('h3','',r.title||r.name||`结果 ${index+1}`));if(r.code||r.date)item.append(node('p','',[r.code,r.date].filter(Boolean).join(' · ')));if(r.details)item.append(node('p','',r.details));if(r.studio)item.append(node('p','',`制作商：${r.studio.name||JSON.stringify(r.studio)}`));if(r.performers?.length)item.append(node('p','',`演员：${r.performers.map(x=>x.name||'').join('、')}`));if(r.tags?.length)item.append(node('p','',`标签：${r.tags.map(x=>x.name).join('、')}`));r.urls.forEach(url=>item.append(node('div','source-url',url)));item.append(node('p','help',`规则 ${short(r.rules_version)} · ${r.scraper_id}`));
    if(search){const button=node('button','secondary','选择此候选，获取详情 →');button.addEventListener('click',()=>{const rule=scrapers.find(e=>e.id===payload.scraper_id),queryFragment=rule?.operations.some(o=>o.object===payload.object&&o.operation==='query_fragment'&&o.state==='available');const request={scraper_id:payload.scraper_id,object:payload.object,rules_version:response.rules_version};if(queryFragment){request.fragment=r.raw;request.operation='query_fragment';}else if(r.urls.length){request.url=r.urls[0];}else{request.fragment=r.raw;request.operation='fragment';}execute(request,false);});item.append(button);}
    const detail=node('details');detail.append(node('summary','','原始结果'),node('pre','',JSON.stringify(r.raw,null,2)));item.append(detail);container.append(item);
  });
}
$('#debug-form').addEventListener('submit',event=>{
  event.preventDefault();if(abortController)return;
  if(!debugSelection().ready){toast('请选择依赖齐全且已启用的操作。');return;}
  const mode=$('#debug-mode').value,payload={scraper_id:$('#debug-scraper').value,object:$('#debug-object').value};
  if(mode==='query')payload.query=$('#debug-input').value;
  else if(mode==='url'){
    const value=$('#debug-input').value.trim();try{const url=new URL(value);if(!['http:','https:'].includes(url.protocol))throw new Error();}catch{toast('此操作需要完整的 HTTP(S) 详情页 URL，不能填写名称或番号。');return;}payload.url=value;
  }else{
    try{payload.fragment=JSON.parse($('#debug-input').value);if(!payload.fragment||Array.isArray(payload.fragment)||typeof payload.fragment!=='object'||!Object.keys(payload.fragment).length)throw new Error();}catch{toast('Fragment 必须是非空 JSON 对象。');return;}payload.operation=mode;
  }
  execute(payload,mode==='query');
});
$('#cancel').addEventListener('click',()=>abortController?.abort());
function renderUpdates(){
  const {state:s,schedule:c,retained}=updates;$('#update-stage').textContent=phaseNames[s.phase]||s.phase;$('#update-explanation').textContent=s.failure||`下次检测：${date(s.next_check)}（${c.timezone}）`;$('#pause-updates').textContent=c.enabled?'暂停更新':'恢复每日跟随';$('#pin-version').value=c.pin||'';
  const facts=[['当前生效规则 commit',s.active||'尚未安装'],['当前引擎',s.engine],['最近检测的上游 commit',s.upstream||'尚未检测'],['上次检查',date(s.last_check)],['下次计划',date(s.next_check)],['最近成功应用',date(s.last_success)]];$('#update-facts').replaceChildren(...facts.map(([label,value])=>{const d=node('div','fact');d.append(node('small','',label),node('strong','',value));return d;}));
  const versions=$('#rollback-version');versions.replaceChildren();retained.filter(m=>m.version!==s.active).forEach(m=>{const o=node('option','',`${short(m.version)} · ${date(m.created)}`);o.value=m.version;versions.append(o);});$('#rollback').disabled=!versions.options.length;
  const history=$('#update-history');history.replaceChildren();[...s.history].reverse().forEach(h=>{const row=node('div','history-item'),message=node('div');message.append(node('code','',`${h.action==='rollback'?'回滚':h.action==='validate'?'兼容验证':'应用更新'} · ${short(h.version)}`));if(h.reason)message.append(node('p','',h.reason));row.append(node('time','',date(h.at)),message,node('span',`badge ${h.result==='ok'?'':'unsupported'}`,h.result==='ok'?'成功':'失败'));history.append(row);});if(!s.history.length)history.append(node('p','help','暂无历史记录。首次初始化完成后，版本记录将显示在这里。'));
}
function renderSettings(){if(!configuration)return;const c=configuration;const values={proxy:c.proxy,timeout:c.timeout_seconds,concurrency:c.concurrency,rate:c.site_interval_ms,python:c.python_base,cdp:c.cdp,local:c.local_dir,repo:c.source.repository,branch:c.source.branch,interval:c.update.interval_hours,daily:c.update.daily_at,timezone:c.update.timezone,retain:c.update.retain};Object.entries(values).forEach(([k,v])=>$(`#cfg-${k}`).value=v??'');$('#cfg-private').checked=c.allow_private_targets;$('#advanced-config').value=JSON.stringify(c,null,2);}
$('#settings-form').addEventListener('input',()=>settingsDirty=true);
$('#settings-form').addEventListener('submit',event=>{event.preventDefault();if(!configuration){toast('请先连接服务。');return;}const c=structuredClone(configuration);c.proxy=$('#cfg-proxy').value.trim();c.timeout_seconds=+$('#cfg-timeout').value;c.concurrency=+$('#cfg-concurrency').value;c.site_interval_ms=+$('#cfg-rate').value;c.python_base=$('#cfg-python').value.trim();c.cdp=$('#cfg-cdp').value.trim();c.local_dir=$('#cfg-local').value.trim();c.allow_private_targets=$('#cfg-private').checked;c.source.repository=$('#cfg-repo').value.trim();c.source.branch=$('#cfg-branch').value.trim();c.update.interval_hours=+$('#cfg-interval').value;c.update.daily_at=$('#cfg-daily').value;c.update.timezone=$('#cfg-timezone').value.trim();c.update.retain=+$('#cfg-retain').value;mutate(()=>api('/api/config',{method:'PUT',body:JSON.stringify(c)}),'配置已保存',true);});
$('#save-advanced').addEventListener('click',()=>{try{const c=JSON.parse($('#advanced-config').value);mutate(()=>api('/api/config',{method:'PUT',body:JSON.stringify(c)}),'完整配置已保存',true);}catch(e){toast('完整配置必须是有效 JSON。');}});
$('#save-token').addEventListener('click',()=>{sessionStorage.setItem('stash-token',$('#service-token').value);$('#service-token').value='';settingsDirty=false;refresh();});
async function mutate(action,message,clearDirty=false){if(busy){toast('请等待当前操作完成。');return;}busy=true;const progress=setInterval(refreshUpdateOnly,1500);try{await action();if(clearDirty)settingsDirty=false;toast(message);}catch(e){toast(e.message);}finally{clearInterval(progress);busy=false;await refresh();}}
async function refreshUpdateOnly(){try{updates=await api('/api/updates');renderUpdates();}catch(e){/* surfaced by the active operation */}}
async function changeUpdate(change,message){if(!configuration)return;const c=structuredClone(configuration);Object.assign(c.update,change);await mutate(()=>api('/api/config',{method:'PUT',body:JSON.stringify(c)}),message);}
$('#pin-form').addEventListener('submit',event=>{event.preventDefault();changeUpdate({pin:$('#pin-version').value.trim(),pin_until:'0001-01-01T00:00:00Z'},'版本固定策略已保存');});
$('#pause-updates').addEventListener('click',()=>changeUpdate({enabled:!configuration.update.enabled},configuration.update.enabled?'自动更新已暂停':'自动更新已恢复'));
$('#check-now').addEventListener('click',()=>mutate(()=>api('/api/updates/check',{method:'POST'}),'上游检查完成'));
$('#install-upstream').addEventListener('click',()=>{tab('updates');mutate(()=>api('/api/install',{method:'POST',body:JSON.stringify({source:'upstream'})}),'社区资源同步完成');});
$('#install-local').addEventListener('click',()=>mutate(()=>api('/api/install',{method:'POST',body:JSON.stringify({source:'local'})}),'本地完整目录安装完成'));
$('#rollback').addEventListener('click',()=>mutate(()=>api('/api/updates/rollback',{method:'POST',body:JSON.stringify({version:$('#rollback-version').value})}),'已回滚，版本临时固定 24 小时'));
$('#reload').addEventListener('click',()=>mutate(()=>api('/api/reload',{method:'POST'}),'运行配置与规则已重新加载'));
$('#refresh').addEventListener('click',refresh);$('#filter').addEventListener('input',renderLibrary);$('#status-filter').addEventListener('change',renderLibrary);
async function refreshLogs(){try{const data=await api('/api/logs');const list=$('#logs-list');list.replaceChildren();[...data.logs].reverse().forEach(log=>{const row=node('div','log-row');row.append(node('time','',date(log.at)),node('span',log.level,log.level.toUpperCase()),node('span','',log.message));list.append(row);});if(!data.logs.length)list.append(node('p','help','暂无运行事件。更新与回滚记录可在版本管理中查看。'));}catch(e){toast(e.message);}}
$('#refresh-logs').addEventListener('click',refreshLogs);
refresh();setInterval(()=>{if(!busy&&!document.hidden)refreshUpdateOnly();},15000);
